# ticketX™ — React + TypeScript

Site convertido de HTML puro para React com TypeScript.

## 🚀 Como rodar

### 1. Instalar dependências
```bash
npm install
```

### 2. Rodar em desenvolvimento
```bash
npm run dev
```
Acesse: http://localhost:5173

### 3. Build para produção
```bash
npm run build
```

---

## 📁 Estrutura do projeto

```
ticketx/
├── index.html
├── vite.config.ts
├── tsconfig.json
├── package.json
├── public/
│   └── assets/          ← coloque suas imagens aqui
│       ├── WEDONACOPA.jpg
│       ├── AMORÉ LANÇAMENTO.png
│       ├── FOGUEIRA GRADE.jpeg
│       ├── GINGA GRADE.png
│       ├── MANIFESTO LANÇAMENTO.PNG
│       └── ARENAN1.jpg
│   └── img/
│       └── MOSAICO_ticketX_01.png
└── src/
    ├── main.tsx          ← entrada da aplicação
    ├── App.tsx           ← componente raiz
    ├── index.css         ← estilos globais
    ├── types.ts          ← tipos TypeScript
    ├── data.ts           ← dados (eventos, FAQ, feedbacks)
    └── components/
        ├── CustomCursor.tsx
        ├── Navbar.tsx
        ├── Hero.tsx
        ├── Sobre.tsx
        ├── Beneficios.tsx
        ├── Eventos.tsx
        ├── EventoCard.tsx
        ├── Faq.tsx
        ├── Feedbacks.tsx
        ├── Cta.tsx
        └── Footer.tsx
```

## 🖼️ Imagens

Coloque todas as imagens de eventos na pasta `public/assets/` e a imagem do mosaico em `public/img/`.

## ✏️ Como editar eventos

Abra `src/data.ts` e edite o array `eventos`:

```typescript
export const eventos: Evento[] = [
  {
    id: 1,
    nome: 'Nome do Evento',
    local: 'Cidade',
    imagem: '/assets/imagem.jpg',
    preco: 'R$100',
    precoLabel: 'Ingresso',
    whatsappMsg: 'Olá, tenho interesse no ingresso do Evento X.',
  },
  // ...
]
```

## ✏️ Como editar FAQ

No mesmo `src/data.ts`, edite o array `faqItems`.

## 🛠️ Tecnologias

- React 18
- TypeScript 5
- Vite 4
