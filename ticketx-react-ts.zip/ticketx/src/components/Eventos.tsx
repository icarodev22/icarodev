import { eventos } from '../data'
import EventoCard from './EventoCard'

export default function Eventos() {
  return (
    <section className="eventos" id="eventos">
      <div className="eventos-inner">
        <div className="section-label">eventos_</div>

        <h2>
          Festas <em>disponíveis</em>
        </h2>

        <p className="eventos-sub">Garanta seu ingresso sem complicação.</p>

        <div className="eventos-grid">
          {eventos.map((evento) => (
            <EventoCard key={evento.id} evento={evento} />
          ))}
        </div>
      </div>
    </section>
  )
}
