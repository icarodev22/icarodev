import { feedbacks } from '../data'

export default function Feedbacks() {
  return (
    <section className="feedbacks" id="feedbacks">
      <div className="feedbacks-inner">
        <div className="section-label">feedbacks_</div>

        <div className="feedback-track">
          {feedbacks.map((fb, index) => (
            <div className="feedback-card" key={index}>
              {'★'.repeat(fb.estrelas)}

              <p>"{fb.texto}"</p>

              {fb.autor && (
                <small style={{ color: 'rgba(255,255,255,0.4)', fontSize: '0.8rem' }}>
                  — {fb.autor}
                </small>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
