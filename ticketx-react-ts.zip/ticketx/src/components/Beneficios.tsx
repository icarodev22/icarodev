import { benefits } from '../data'

export default function Beneficios() {
  return (
    <section className="conosco" id="conosco">
      <div className="conosco-inner">
        <div className="section-label">conosco_</div>

        <h2>Por que escolher a TicketX?</h2>

        <div className="benefits-grid">
          {benefits.map((b) => (
            <div className="benefit-card" key={b.titulo}>
              <h3>
                {b.icone} {b.titulo}
              </h3>
              <p>{b.descricao}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
