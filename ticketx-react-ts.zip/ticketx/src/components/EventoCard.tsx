import type { Evento } from '../types'
import { WHATSAPP_BASE } from '../data'

interface EventoCardProps {
  evento: Evento
}

export default function EventoCard({ evento }: EventoCardProps) {
  const href = evento.link
    ? evento.link
    : `${WHATSAPP_BASE}?text=${encodeURIComponent(evento.whatsappMsg)}`

  return (
    <div className="evento-card">
      <img src={evento.imagem} alt={evento.nome} />

      <div className="evento-info">
        <h3>{evento.nome}</h3>
        <span className="evento-local">📍 {evento.local}</span>

        <div className="evento-bottom">
          <div>
            <small>{evento.precoLabel}</small>
            <strong>{evento.preco}</strong>
          </div>

          <a href={href} target="_blank" rel="noreferrer">
            Comprar
          </a>
        </div>
      </div>
    </div>
  )
}
