export default function Sobre() {
  return (
    <section className="sobre" id="sobre">
      <div className="sobre-inner">
        <div className="sobre-text">
          <div className="section-label">sobre nós_</div>

          <h2>
            Conectando você às{' '}
            <em>melhores experiências</em>
          </h2>

          <p>
            A TicketX atua na venda de ingressos conectando você aos melhores
            eventos.
          </p>

          <p>Segurança, praticidade e suporte real.</p>
        </div>

        <img
          src="/img/MOSAICO_ticketX_01.png"
          alt="TicketX Mosaico"
          className="sobre-img"
        />
      </div>
    </section>
  )
}
