interface HeroProps {
  onScrollTo: (id: string) => void
}

export default function Hero({ onScrollTo }: HeroProps) {
  return (
    <section className="hero">
      <div className="hero-bg" />

      <div className="hero-content">
        <div className="hero-badge">
          🎟 Comissário autorizado de grandes produtoras
        </div>

        <h1 className="hero-title">
          <span className="line-blue">seus</span>
          <br />
          <span className="line-mag">ingressos_</span>
          <br />
          sem taxa.
        </h1>

        <p className="hero-sub">
          A TicketX conecta você aos melhores eventos com praticidade, segurança
          e benefícios exclusivos.
        </p>

        <div className="hero-actions">
          <button
            className="btn-primary"
            onClick={() => onScrollTo('eventos')}
          >
            🎟 Garantir meu ingresso
          </button>

          <button
            className="btn-ghost"
            onClick={() => onScrollTo('sobre')}
          >
            Saiba mais
          </button>
        </div>
      </div>
    </section>
  )
}
