import { WHATSAPP_BASE } from '../data'

export default function Cta() {
  return (
    <section className="cta-section">
      <div className="section-label">garanta já_</div>

      <h2>
        Bora pro próximo <em>evento?</em>
      </h2>

      <p>Chama no WhatsApp e garante teu ingresso.</p>

      <div className="hero-actions">
        <a href={WHATSAPP_BASE} target="_blank" rel="noreferrer" className="btn-primary">
          WhatsApp
        </a>
      </div>
    </section>
  )
}
