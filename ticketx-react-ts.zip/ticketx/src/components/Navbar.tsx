interface NavbarProps {
  onScrollTo: (id: string) => void
}

export default function Navbar({ onScrollTo }: NavbarProps) {
  return (
    <nav>
      <a href="#" className="nav-logo">
        ticket<span>X</span>™
      </a>

      <ul className="nav-links">
        {[
          { label: 'Sobre nós', id: 'sobre' },
          { label: 'Benefícios', id: 'conosco' },
          { label: 'Eventos', id: 'eventos' },
          { label: 'Dúvidas', id: 'faq' },
          { label: 'Feedbacks', id: 'feedbacks' },
        ].map((item) => (
          <li key={item.id}>
            <a
              href={`#${item.id}`}
              onClick={(e) => {
                e.preventDefault()
                onScrollTo(item.id)
              }}
            >
              {item.label}
            </a>
          </li>
        ))}
      </ul>

      <button className="nav-cta" onClick={() => onScrollTo('eventos')}>
        Comprar ingresso
      </button>
    </nav>
  )
}
