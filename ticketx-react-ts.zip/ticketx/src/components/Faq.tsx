import { useState } from 'react'
import { faqItems } from '../data'

export default function Faq() {
  const [openIndex, setOpenIndex] = useState<number | null>(null)

  const toggle = (index: number) => {
    setOpenIndex(openIndex === index ? null : index)
  }

  return (
    <section className="faq" id="faq">
      <div className="faq-inner">
        <div className="section-label">dúvidas_</div>

        <h2>Perguntas frequentes</h2>

        {faqItems.map((item, index) => (
          <div className="faq-item" key={index}>
            <button
              className={`faq-q ${openIndex === index ? 'open' : ''}`}
              onClick={() => toggle(index)}
            >
              {item.pergunta}
              <span>▾</span>
            </button>

            <div className={`faq-a ${openIndex === index ? 'open' : ''}`}>
              {item.resposta}
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
