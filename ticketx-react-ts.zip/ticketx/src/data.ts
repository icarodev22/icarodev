import type { Evento, FaqItem, FeedbackItem, BenefitItem } from './types'

export const WHATSAPP_BASE = 'https://wa.me/5581992777571'

export const eventos: Evento[] = [
  {
    id: 1,
    nome: 'Wedo Na Copa',
    local: 'Recife',
    imagem: '/assets/WEDONACOPA.jpg',
    preco: 'R$120',
    precoLabel: 'Ingresso',
    whatsappMsg: 'Olá, tenho interesse no ingresso do Wedo na Copa.',
  },
  {
    id: 2,
    nome: 'Amoré Réveillon',
    local: 'Maracaípe',
    imagem: '/assets/AMORÉ LANÇAMENTO.png',
    preco: 'link Com 5% OFF',
    precoLabel: 'Ingresso',
    whatsappMsg: 'Olá, tenho interesse no ingresso do Amoré Réveillon.',
  },
  {
    id: 3,
    nome: 'Carvalheira na Fogueira',
    local: 'Campina Grande',
    imagem: '/assets/FOGUEIRA GRADE.jpeg',
    preco: 'CONSULTAR',
    precoLabel: 'Ingresso',
    whatsappMsg: 'Olá, tenho interesse no ingresso do Carvalheira na Fogueira.',
  },
  {
    id: 4,
    nome: 'Ginga Recife',
    local: 'Recife',
    imagem: '/assets/GINGA GRADE.png',
    preco: 'R$100',
    precoLabel: 'Ingresso',
    whatsappMsg: 'Olá, tenho interesse no ingresso do Ginga Recife.',
  },
  {
    id: 5,
    nome: 'Manifesto Musical',
    local: 'Recife',
    imagem: '/assets/MANIFESTO LANÇAMENTO.PNG',
    preco: 'R$100',
    precoLabel: 'Ingresso',
    whatsappMsg: 'Olá, tenho interesse no ingresso do Manifesto Musical.',
  },
  {
    id: 6,
    nome: 'ARENA N1°',
    local: 'Recife',
    imagem: '/assets/ARENAN1.jpg',
    preco: 'Link Com 5% OFF',
    precoLabel: 'Ingressos',
    whatsappMsg: '',
    link: 'https://www.sympla.com.br/evento/arena-n1-em-recife/3415182?d=TICKETX',
  },
]

export const faqItems: FaqItem[] = [
  {
    pergunta: 'Como funciona a compra?',
    resposta: 'Escolha o evento, pague e receba digitalmente.',
  },
  {
    pergunta: 'Os ingressos são seguros?',
    resposta: 'Sim, todos os ingressos são validados.',
  },
]

export const feedbacks: FeedbackItem[] = [
  {
    estrelas: 5,
    texto: 'Comprei rápido e chegou na hora.',
  },
  {
    estrelas: 5,
    texto: 'Melhor plataforma de ingressos.',
  },
]

export const benefits: BenefitItem[] = [
  {
    icone: '⚡',
    titulo: 'Compra rápida',
    descricao: 'Processo simples e direto.',
  },
  {
    icone: '🏷️',
    titulo: 'Sem taxa',
    descricao: 'Ingressos com preço justo.',
  },
  {
    icone: '💬',
    titulo: 'Suporte online',
    descricao: 'Atendimento rápido no WhatsApp.',
  },
]
