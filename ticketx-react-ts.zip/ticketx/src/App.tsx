import CustomCursor from './components/CustomCursor'
import Navbar from './components/Navbar'
import Hero from './components/Hero'
import Sobre from './components/Sobre'
import Beneficios from './components/Beneficios'
import Eventos from './components/Eventos'
import Faq from './components/Faq'
import Feedbacks from './components/Feedbacks'
import Cta from './components/Cta'
import Footer from './components/Footer'

function scrollTo(id: string) {
  const el = document.getElementById(id)
  if (el) el.scrollIntoView({ behavior: 'smooth' })
}

export default function App() {
  return (
    <>
      <CustomCursor />
      <Navbar onScrollTo={scrollTo} />
      <Hero onScrollTo={scrollTo} />
      <Sobre />
      <Beneficios />
      <Eventos />
      <Faq />
      <Feedbacks />
      <Cta />
      <Footer />
    </>
  )
}
