export interface Evento {
  id: number
  nome: string
  local: string
  imagem: string
  preco: string
  precoLabel: string
  whatsappMsg: string
  link?: string
}

export interface FaqItem {
  pergunta: string
  resposta: string
}

export interface FeedbackItem {
  estrelas: number
  texto: string
  autor?: string
}

export interface BenefitItem {
  icone: string
  titulo: string
  descricao: string
}
